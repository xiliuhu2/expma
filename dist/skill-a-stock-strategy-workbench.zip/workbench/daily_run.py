#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
每日收盘跑批：更新K线 → 重启策略工作台 → 三策略筛选 + regime → 生成日报
用法：python3 daily_run.py
stdout 输出 JSON 摘要（供自动化/人工读取）
"""
import datetime, json, os, subprocess, sys, time, urllib.request

BASE = os.path.expanduser('~/WorkBuddy/Claw')
PORT = 8765
URL = 'http://127.0.0.1:%d' % PORT
DAILY_DIR = os.path.join(BASE, 'daily')
os.makedirs(DAILY_DIR, exist_ok=True)

# 筛选市值上限：99999 = 全市场口径（snapshot.json 5010只，去除ST/退市/停牌）。
# 注意：四策略回测样本为小盘（<=100亿），大市值命中未经回测验证，仅供观察。
MV_MAX = 99999

out = {'status': 'ok', 'steps': {}}

def fail(step, msg):
    out['status'] = 'error'
    out['steps'][step] = msg
    print(json.dumps(out, ensure_ascii=False))
    sys.exit(1)

# 离线模式：SKIP_FETCH=1 跳过所有联网抓取/重启/DQ闸门，直接用现有缓存与运行中的工作台
# 重算信号、三线池、跟踪与报告（用于盘中复盘或修复报告，不影响收盘自动化）
SKIP_FETCH = os.environ.get('SKIP_FETCH') == '1'
if SKIP_FETCH:
    out['steps']['offline'] = 'SKIP_FETCH=1: 使用现有K线缓存，跳过抓取/重启/DQ'
else:
    # 0) 刷新指数日K（上证/科创50/创业板指/北证50）+ 股债长跑数据（上证全历史/上证国债指数）
    ri = subprocess.run([sys.executable, BASE + '/backtest/fetch_indices.py'],
                        capture_output=True, text=True, timeout=300)
    out['steps']['indices'] = 'ok' if ri.returncode == 0 else ri.stderr[-200:]
    rb = subprocess.run([sys.executable, BASE + '/backtest/fetch_bond.py'],
                        capture_output=True, text=True, timeout=300)
    out['steps']['bond'] = 'ok' if rb.returncode == 0 else rb.stderr[-200:]
    # 0.5) 更新行业分类（东方财富 f100，涨停复盘主线聚合用；行业归属极少变动）
    ri2 = subprocess.run([sys.executable, BASE + '/backtest/fetch_industry.py'],
                         capture_output=True, text=True, timeout=300)
    out['steps']['industry'] = (ri2.stdout.strip().splitlines() or [''])[-1] if ri2.returncode == 0 else ri2.stderr[-200:]
    # 0.6) 概念板块映射（主线识别用概念；归属变动慢，数据超过5天才刷新，约2分钟）
    _con_path = BASE + '/webapp/concepts.json'
    _stale = True
    try:
        import datetime as _dt
        _age = (_dt.date.today() - _dt.date.fromisoformat(json.load(open(_con_path))['fetched'])).days
        _stale = _age >= 5
    except Exception:
        pass
    if _stale:
        rc = subprocess.run([sys.executable, BASE + '/backtest/fetch_concepts.py'],
                            capture_output=True, text=True, timeout=600)
        out['steps']['concepts'] = (rc.stdout.strip().splitlines() or [''])[-1] if rc.returncode == 0 else rc.stderr[-200:]
    else:
        out['steps']['concepts'] = 'fresh(≤5天跳过)'
    # 0.7) 沪深300成份股主档（基础数据本地化：主档超7天才联网刷新，留痕调入/调出）
    rh = subprocess.run([sys.executable, BASE + '/backtest/fetch_hs300.py'],
                        capture_output=True, text=True, timeout=120)
    out['steps']['hs300'] = (rh.stdout.strip().splitlines() or [''])[-1] if rh.returncode == 0 else rh.stderr[-200:]

    # 1) 更新K线缓存（--refresh 全量重抓，纳入最新交易日）
    r = subprocess.run([sys.executable, BASE + '/backtest/fetch_klines.py', '--refresh'],
                       capture_output=True, text=True, timeout=900)
    out['steps']['fetch'] = (r.stdout.strip().splitlines() or [''])[-1]
    if r.returncode != 0:
        fail('fetch', r.stderr[-500:])

    # 2) 重启工作台（载入新数据）
    subprocess.run("lsof -ti tcp:%d | xargs kill -9 2>/dev/null; true" % PORT,
                   shell=True, capture_output=True)
    srv = subprocess.Popen([sys.executable, BASE + '/webapp/server.py', str(PORT)],
                           stdout=open(BASE + '/webapp/server.log', 'a'),
                           stderr=subprocess.STDOUT, start_new_session=True)
    for _ in range(90):
        try:
            urllib.request.urlopen(URL + '/api/regime', timeout=5)
            break
        except Exception:
            time.sleep(2)
    else:
        fail('server', '工作台启动超时，日志: ' + open(BASE + '/webapp/server.log').read()[-500:])

    # 2.5) 重启到价提醒守护进程（盘中轮询腾讯实时行情，到价弹 macOS 通知）
    subprocess.run("pkill -f 'alertd.py' 2>/dev/null; true", shell=True, capture_output=True)
    try:
        subprocess.Popen([sys.executable, BASE + '/webapp/alertd.py'],
                         stdout=open(BASE + '/webapp/alertd.log', 'a'),
                         stderr=subprocess.STDOUT, start_new_session=True)
        out['steps']['alertd'] = 'restarted'
    except Exception as e:
        out['steps']['alertd'] = str(e)

    # 2.5b) 重启三线穿阳·破20日高 盘中提醒守护（预触发口径，见 tlbreak_alert.py）
    subprocess.run("pkill -f 'tlbreak_alert.py' 2>/dev/null; true", shell=True, capture_output=True)
    try:
        subprocess.Popen([sys.executable, BASE + '/webapp/tlbreak_alert.py'],
                         stdout=open(BASE + '/webapp/alertd.log', 'a'),
                         stderr=subprocess.STDOUT, start_new_session=True)
        out['steps']['tlbreak_alert'] = 'restarted'
    except Exception as e:
        out['steps']['tlbreak_alert'] = str(e)

    # 2.6) 基础数据体检（DQ 闸门）：覆盖/新鲜度/结构/涨跌幅越界/跨源抽样/派生指标一致
    #      不通过则中止，绝不把脏数据写进观察池与日报
    rd = subprocess.run([sys.executable, BASE + '/backtest/dq_check.py', '--quiet'],
                        capture_output=True, text=True, timeout=600)
    _dq = None
    for _ln in rd.stdout.splitlines():
        if _ln.startswith('DQJSON '):
            try:
                _dq = json.loads(_ln[7:])
            except Exception:
                _dq = None
    if _dq is None:
        fail('dq', '数据体检无输出: ' + ((rd.stderr or rd.stdout or '')[-400:]))
    out['dq'] = {'status': _dq['status'], 'stale': _dq.get('stale'),
                 'checks': {c['name']: c['level'] for c in _dq['checks']}}
    if _dq['status'] == 'error':
        _bad = ['%s: %s' % (c['name'], c['detail']) for c in _dq['checks'] if c['level'] == 'error']
        fail('dq', '数据体检未通过 → ' + ' | '.join(_bad)[:450])



# 3) 拉取 regime + 三策略结果
def get(path):
    return json.load(urllib.request.urlopen(URL + path, timeout=180))

try:
    regime = get('/api/regime')
    res = {s: get('/api/screen?strategy=%s&mvmax=%d' % (s, MV_MAX))
           for s in ('pre', 'dk', 'never', 'dc', 'm89', 'cross')}
    indices = get('/api/indices')
    bond = get('/api/bond_stock')
    zt = get('/api/zt?days=20')
    emo = get('/api/emotion?days=30')
    picks = get('/api/picks')
    hs = get('/api/hs300')
    out['bond'] = {k: bond.get(k) for k in ('anchor', 'anchor_sse', 'sse_now', 'bond_now', 'ratio', 'bond_date')} \
        if 'error' not in bond else {'error': bond['error']}
    out['indices'] = [{'name': d['name'], 'close': d['close'], 'chg': d['chg'],
                       'above12': d['above12'], 'date': d['date'],
                       'last_cross_up': d['cross_up'][-1] if d['cross_up'] else None} for d in indices]
except Exception as e:
    fail('api', str(e))

cur = regime['current']
out['date'] = res['pre']['date'] or res['dk']['date'] or res['never']['date']
out['regime'] = {'current': cur, 'mom20': regime['mom20'], 'mkt': regime.get('mkt')}
out['counts'] = {s: res[s]['count'] for s in res}
out['top'] = {s: [{'code': r['code'], 'name': r['name'], 'c20': r['c20'], 'chg': r['chg'],
                   'lines': r.get('lines')}
                  for r in res[s]['rows'][:5]] for s in res}

# 3.5) 观察池更新（信号入池 → 前向跟踪 → 平仓积累真实收益数据）
try:
    sys.path.insert(0, BASE + '/webapp')
    import server as _srv, pool as _pool
    D2 = _srv.Data()
    meta = D2.meta
    sig_fns = {
        'pre': lambda code, kk, t: _srv.sig_pre(kk, t) and meta.get(code, {}).get('mv', MV_MAX + 1) <= MV_MAX and _srv.pe_ok(meta.get(code, {})) and not _srv.is_st(meta.get(code, {}).get('name')),
        'dk': lambda code, kk, t: _srv.sig_dk(kk, t) and meta.get(code, {}).get('mv', MV_MAX + 1) <= MV_MAX and _srv.pe_ok(meta.get(code, {})) and not _srv.is_st(meta.get(code, {}).get('name')),
        'never': lambda code, kk, t: _srv.sig_never(kk, t) and meta.get(code, {}).get('mv', MV_MAX + 1) <= MV_MAX and _srv.pe_ok(meta.get(code, {})) and not _srv.is_st(meta.get(code, {}).get('name')),
        'dc': lambda code, kk, t: _srv.sig_dc(kk, t) and meta.get(code, {}).get('mv', MV_MAX + 1) <= MV_MAX and _srv.pe_ok(meta.get(code, {})) and not _srv.is_st(meta.get(code, {}).get('name')),
        'm89': lambda code, kk, t: _srv.sig_m89(kk, t) and meta.get(code, {}).get('mv', MV_MAX + 1) <= MV_MAX and _srv.pe_ok(meta.get(code, {})) and not _srv.is_st(meta.get(code, {}).get('name')),
        'cross': lambda code, kk, t: _srv.sig_cross(kk, t) and meta.get(code, {}).get('mv', MV_MAX + 1) <= MV_MAX and _srv.pe_ok(meta.get(code, {})) and not _srv.is_st(meta.get(code, {}).get('name')),
    }
    pr = _pool.update(D2, sig_fns)
    pl_stats = _pool.stats(_pool.load())
    # 「今日新入池」按 entry_date 统计（幂等：同一天重复跑批不会把已入池的算漏）
    _today = [e for e in pr['open'] if e.get('entry_date') == pr['data_date']]
    out['pool'] = {
        'added': len(_today),
        'exited': len(pr['exited']),
        'open_by_strategy': {s: pl_stats[s]['open'] for s in _pool.STRATS},
        'added_list': [{'code': e['code'], 'name': e['name'], 'strategy': _pool.SNAME[e['strategy']]} for e in _today],
        'exited_list': [{'code': e['code'], 'name': e['name'], 'ret': e['ret'], 'reason': e['reason']} for e in pr['exited']],
        'stats': pl_stats,
    }
    # D2 延后释放：3.6 三线池/全量跟踪复用同一份已加载的 K线数据（避免重复读5000个文件）
except Exception as e:
    out['pool'] = {'error': str(e)}

# 3.6) 穿三线（用户操作重点）：全量持续跟踪 ≥30交易日 + 当日 Top5「三线池」
#      顺序：先 tltrack（回填/刷新前向统计）→ 再 tlpool（评分依据取最新 evidence）
try:
    import server as _srv2
    if 'D2' not in globals():
        D2 = _srv2.Data()   # 3.5 失败时的兜底，保证三线池/跟踪不被连带跳过
    import tltrack as _trk, tlpool as _tlp
    tr = _trk.update(D2)
    tp = _tlp.build(D2, ctx={'regime': regime, 'indices': indices,
                             'zt': zt, 'emotion': emo})
    out['tltrack'] = {
        'as_of': tr['as_of'], 'live_from': tr['live_from'],
        'n_signals': tr['n_signals'], 'matured': tr['n_matured'],
        'tracking': tr['n_tracking'], 'snapshots': tr['snapshots'],
        'd5': tr.get('d5'),
    }
    out['tlpool'] = {
        'as_of': tp['as_of'], 'n_candidates': tp['n_candidates'],
        'n_confirmed': tp['n_confirmed'], 'n_A': sum(1 for x in tp['pool'] if x['grade'] == 'A'),
        'top5': [{'code': x['code'], 'name': x['name'], 'score': x['score'],
                  'grade': x['grade'], 'pullback': x['entry']['pullback'],
                  'trigger': x['entry']['trigger'], 'hard_stop': x['entry']['hard_stop']}
                 for x in tp['pool']],
    }
    del tr, tp
except Exception as e:
    out['tltrack'] = {'error': str(e)}
    out['tlpool'] = {'error': str(e)}

# 3.6.5) 背离金叉 lead：当前全量候选（不剔除，进池）+ 全历史 ≥30日持续跟踪（回测）
#        与 3.6 复用同一份 D2，避免重复读取 5000 个 K线文件
try:
    if 'D2' not in globals():
        import server as _srv4
        D2 = _srv4.Data()
    import tlpool as _tlp2, divtrack as _dvt
    dc = _tlp2.screen_divcross(D2, D2.px_date, cur, topn=400)
    with open(BASE + '/webapp/divcross.json', 'w') as _fh:
        json.dump(dc, _fh, ensure_ascii=False)
    dv = _dvt.update(D2)
    out['divcross'] = {
        'as_of': dc['as_of'], 'regime': dc['regime'], 'n': dc['n'], 'n_fresh3': dc['n_fresh3'],
    }
    out['divtrack'] = {
        'as_of': dv['as_of'], 'n_signals': dv['n_signals'],
        'matured': dv['n_matured'], 'tracking': dv['n_tracking'],
        'd5': dv.get('d5'),
    }
    del dc, dv
except Exception as e:
    out['divcross'] = {'error': str(e)}
    out['divtrack'] = {'error': str(e)}

# 3.7) 龙头战法：全历史盘面重建 + 次日可成交口径前向验证 + 当日龙头池分级 + 持续跟踪
#     与 3.6 复用同一份 D2，避免重复读取 5000 个 K线文件
try:
    if 'D2' not in globals():
        import server as _srv3
        D2 = _srv3.Data()
    import dragon as _dg
    dr = _dg.update(D2)
    out['dragon'] = {
        'as_of': dr['as_of'], 'n_signals': dr['n_signals'],
        'overall_d5': dr['overall_d5'], 'overall_exc': dr['overall_exc'],
        'n_A': dr['n_A'], 'n_B': dr['n_B'], 'n_D': dr['n_D'],
        'n_candidates': dr['n_candidates'], 'n_pool': dr['n_pool'],
        'leader': dr['leader'], 'phase': dr['phase'],
        'tracking': dr['tracking'], 'matured': dr['matured'],
        'reversed_factors': dr['reversed_factors'],
    }
    del dr
except Exception as e:
    out['dragon'] = {'error': str(e)}
try:
    del D2
except NameError:
    pass

# 非交易日检测：数据日期是否为「今天」且已收盘（不再用 today-4 的宽松窗口，避免假期误判为新数据）
_today = datetime.date.today().isoformat()
_now = datetime.datetime.now()
_after_close = _now.hour > 15 or (_now.hour == 15 and _now.minute >= 10)
out['is_new_data'] = bool(out['date'] == _today and _after_close)
out['non_trading_day'] = bool(out['date'] != _today)

# 4) 生成日报 markdown
if out['date']:
    ds = out['date']
    lines = ['# EXPMA 每日收盘报告 · %s' % ds, '',
             '- Regime：**%s**（等权小盘指数 20 日动量 %+.2f%%）' % (
                 '上行 ▲（可开仓）' if cur == 'up' else '下行 ▼（按回测规则应空仓观察）', regime['mom20']),
             '- 指数可操作窗口：' + '；'.join(
                 '%s %s（%+.2f%%）' % (d['name'], 'EMA12上方 ▲可操作' if d['above12'] else 'EMA12下方 ▼回避', d['chg'])
                 for d in out.get('indices', [])),
             '- 爆发前潜伏：%d 只 | 登康式启动：%d 只 | 从未破线：%d 只 | 双穿阳线：%d 只 | 89金叉启动：%d 只 | 穿线阳：%d 只（其中三线 %d 只）' % (
                 res['pre']['count'], res['dk']['count'], res['never']['count'], res['dc']['count'],
                 res['m89']['count'], res['cross']['count'], res['cross'].get('lines3', 0)),
             '- 筛选范围：沪深A股全市场（剔除ST/退市/停牌；**已放开亏损股**，PE≤0 以「亏损」标注，regime 仍按等权小盘口径与回测一致）', '']
    bd = out.get('bond') or {}
    if bd.get('ratio'):
        lines.insert(4, '- 股债长跑：上证 %.0f 点 vs 国债缩放线 %.0f 点（锚点 %s 对齐，股/债比值 %.2f，>1 为股票长期领先）'
                     % (bd['sse_now'], bd['bond_now'], bd['anchor'], bd['ratio']))
    if not out.get('is_new_data'):
        lines.insert(4, '- ⚠️ 数据日期非今日（非交易日或指数未更新），本报告为最近收盘数据，勿当当日信号执行')
    if (out.get('dq') or {}).get('stale'):
        lines.insert(5, '- 数据体检：%s（停牌/最后bar非基准日 %d 只，已从当日信号与定价中剔除）'
                     % (out['dq']['status'], out['dq']['stale']))
    for s, title in (('pre', '① 爆发前潜伏'), ('dk', '② 登康式启动'), ('never', '③ 从未破线（11日）'),
                     ('dc', '④ 双穿阳线+破20日高'), ('m89', '⑤ 89金叉启动（50上穿89·12在50上方·89走平）'),
                     ('cross', '⑥ 穿线阳（阳柱实体包住EXPMA12/50；3线=MA89也在实体内）')):
        extra = ('，其中三线穿阳 %d 只' % res[s].get('lines3', 0)) if s == 'cross' else ''
        lines.append('## %s（%d 只%s）' % (title, res[s]['count'], extra))
        hd = ['代码', '名称'] + (['穿线'] if s == 'cross' else []) + \
             ['收盘', '涨跌%', '量比', '距EMA12%', '20日%', '60日%', '市值(亿)', 'PE']
        lines.append('| ' + ' | '.join(hd) + ' |')
        lines.append('|' + '---|' * len(hd))
        for r2 in res[s]['rows'][:15]:
            _pe = r2.get('pe')
            _pe_s = ('%.0f' % _pe) if (_pe and _pe > 0) else '亏损'
            cells = [r2['code'], r2['name']]
            if s == 'cross':
                cells.append('★3线' if r2.get('lines') == 3 else '2线')
            cells += [r2['close'], '%+.2f' % r2['chg'],
                      r2['vr'] if r2['vr'] is not None else '-',
                      '%+.1f' % r2['dev12'], '%+.1f' % r2['c20'], '%+.1f' % r2['c60'],
                      '%.0f' % r2['mv'] if r2.get('mv') else '-', _pe_s]
            lines.append('| ' + ' | '.join(str(x) for x in cells) + ' |')
        lines.append('')
    lines.append('- ⑥ 穿线阳为形态观察口径：不设量比≥1.5、不要求破20日高，只看当日阳线实体是否同时包住 '
                 'EXPMA12 / EXPMA50（三线再加 MA89），因此④被量比或20日高挡掉的票（如索辰科技）会出现在这里。'
                 '三线优先排序。**离线前向检验（截至 2026-11-04，全A 15个月）显示：三线形态本身不含明显超额，'
                 '叠加「收盘破20日高」后 5 日期望才由负转正，④现行口径仍是最优**——故⑥定位为观察池，'
                 '实盘优先级以④为准；工作台提供「⑥b 三线+破20日高」可单独看强化子集。')
    lines.append('')
    # 涨停复盘：主线行业 + 可操作候选（牛股大多从涨停启动）
    if emo and emo.get('hist'):
        eh = emo['hist'][-1]
        eprev = emo['hist'][-2] if len(emo['hist']) > 1 else None
        ladder = ' | '.join('%s板×%s' % (k, eh['ladder'][k]) for k in sorted(eh['ladder'], key=lambda x: int(x)))
        lines.append('## 🌡️ 情绪周期（%s · 温度 %.1f°）' % (eh['phase'], eh['temp']))
        lines.append('- 今日：涨停 **%d** 家 · 炸板率 **%.1f%%** · 1进2晋级率 %s · 最高 %d板 · 梯队：%s' % (
            eh['zt'], eh['zb_rate'],
            ('%.0f%%' % eh['promo']) if eh.get('promo') is not None else '-',
            eh['hmax'], ladder))
        if eprev:
            lines.append('- 较昨日：涨停 %d→%d · 温度 %.1f°→%.1f°（%s→%s）· 炸板率 %.1f%%→%.1f%%' % (
                eprev['zt'], eh['zt'], eprev['temp'], eh['temp'], eprev['phase'], eh['phase'],
                eprev['zb_rate'], eh['zb_rate']))
        warns = []
        if eh['zb_rate'] >= 40:
            warns.append('炸板率≥40%（封板质量差）')
        if eh.get('promo') is not None and eh['promo'] < 15:
            warns.append('晋级率<15%（接力意愿弱）')
        if eh['temp'] < 20:
            warns.append('情绪冰点（关注修复初期首板方向）')
        if eh['temp'] >= 60:
            warns.append('情绪高潮（禁追高，警惕透支后退潮）')
        lines.append(('- ⚠️ ' + '；'.join(warns)) if warns else '- 情绪中性，按纪律正常执行')
        lines.append('')
    if zt and zt.get('total') is not None:
        lines.append('## 涨停复盘 · 20日涨停池（%d 家）' % zt['total'])
        ms = zt.get('max_streak')
        lines.append('- 今日涨停 **%d** 家（昨日 %d 家）· 市场最高连板：%s（%d板）' % (
            zt['today'], zt['yesterday'], ms['name'] if ms else '-', ms['streak'] if ms else 0))
        lines.append('- 主线行业（近5日涨停家数 Top5）：')
        lines.append('| 行业 | 近5日家数 | 20日家数 | 代表股（连板×次数） |')
        lines.append('|---|---|---|---|')
        for it in zt['industries'][:5]:
            lines.append('| %s | %d | %d | %s |' % (
                it['ind'], it['n5'], it['n20'],
                '、'.join('%s(%s×%d)' % (s['name'], ('%d板' % s['streak']) if s['streak'] > 1 else '首板', s['zt_count'])
                          for s in it['top'][:3])))
        if zt.get('concepts'):
            lines.append('- 主线概念（近5日涨停家数 Top5，题材比行业更贴近短线资金）：')
            lines.append('| 概念 | 近5日家数 | 20日家数 | 代表股 |')
            lines.append('|---|---|---|---|')
            for it in zt['concepts'][:5]:
                lines.append('| %s | %d | %d | %s |' % (
                    it['con'], it['n5'], it['n20'],
                    '、'.join('%s(×%d)' % (s['name'], s['zt_count']) for s in it['top'][:3])))
        # 精选池前向验证
        if picks:
            pf = picks.get('perf')
            if pf:
                lines.append('- 🔥 精选池本周前向验证：池均 **%+.1f%%** vs 等权基线 %+.1f%% → 超额 **%+.1fpp**' % (
                    pf['pool'], pf['bench'], pf['excess']) if pf.get('bench') is not None
                    else '- 🔥 精选池本周前向验证：池均 %+.1f%%（基线数据不足）' % pf['pool'])
            for h in (picks.get('history') or [])[-4:]:
                s = h.get('summary', {})
                lines.append('  - 上期 %s：池均 %+.1f%% vs 基线 %+.1f%%（超额 %+.1fpp，%d 只）' % (
                    h['week'], s.get('pool', 0), s.get('bench', 0), s.get('excess', 0), s.get('n', 0)))
        act = zt.get('actionable', [])
        lines.append('- 可操作候选（20日内涨停≥2次 + 站上EMA50/MA89 + 未过度透支，共 %d 只，列前15）：' % len(act))
        if act:
            lines.append('| 代码 | 名称 | 行业 | 涨停次数 | 连板 | 距涨停(日) | 20日% | 市值(亿) |')
            lines.append('|---|---|---|---|---|---|---|---|')
            for r2 in act[:15]:
                lines.append('| %s | %s | %s | %d | %d | %d | %+.1f | %.0f |' % (
                    r2['code'], r2['name'], r2['ind'], r2['zt_count'], r2['streak'],
                    r2['since'], r2['c20'], r2['mv'] or 0))
        else:
            lines.append('  今日无可操作候选（可放宽条件看 p5 全部涨停池）')
        lines.append('')
    # 沪深300 · EXPMA双线向上池（大盘趋势票：入池/剔除/每周Top5）
    if hs and hs.get('pool_n') is not None:
        lines.append('## 沪深300 · EXPMA双线向上池（%d/%d 只在池）' % (hs['pool_n'], hs['total_cons']))
        lines.append('- 口径：收盘 > EMA12 > EMA50 且双线向上（EMA12五日、EMA50十日斜率>0）；走坏收盘确认剔除，止损统一 EMA12×0.98')
        pev = hs.get('picks_evicted') or []
        if pev:
            lines.append('- 本周额度票剔除：%s' % '、'.join('%s(%s)' % (e['name'], e.get('why', '')) for e in pev))
        ev = hs.get('evicted') or []
        if ev:
            lines.append('- 近期剔除：%s' % '；'.join('%s(%s,%s)' % (e['name'], e['date'], e['why']) for e in ev[:5]))
        lines.append('- 🔥 本周可操作 Top5（评分：趋势30+位置25+动能25+流动性10+相对强度10）：')
        lines.append('| 代码 | 名称 | 行业 | 评分 | 选入价 | 距EMA12% | 止损 | 理由 |')
        lines.append('|---|---|---|---|---|---|---|---|')
        for e in hs['picks']['list']:
            lines.append('| %s | %s | %s | %.1f | %s | %+.1f | %.2f | %s |' % (
                e['code'], e['name'], e.get('ind', ''), e.get('score', 0),
                e.get('pick_price'), e.get('dist12') or 0, e.get('stop'), e.get('reason', '')))
        if hs.get('perf') and hs['perf'].get('bench') is not None:
            lines.append('- 本周前向验证：池均 %+.1f%% vs 基线 %+.1f%% → 超额 %+.1fpp' % (
                hs['perf']['pool'], hs['perf']['bench'], hs['perf']['excess']))
        lines.append('')
    pl = out.get('pool')
    if pl and 'error' not in pl:
        lines.append('## 观察池（前向跟踪）')
        lines.append('- 今日新入池 %d 笔：%s' % (pl['added'],
            '、'.join('%s(%s,%s)' % (e['name'], e['code'], e['strategy']) for e in pl['added_list']) or '无'))
        if pl['exited_list']:
            lines.append('- 今日退出 %d 笔：%s' % (len(pl['exited_list']),
                '、'.join('%s(%s) %+.2f%% [%s]' % (e['name'], e['code'], e['ret'], e['reason']) for e in pl['exited_list'])))
        ob = pl['open_by_strategy']
        lines.append('- 池内在跟：爆发前潜伏 %d / 登康式 %d / 从未破线 %d / 双穿阳线 %d / 89金叉启动 %d / 穿线阳 %d' % (
            ob['pre'], ob['dk'], ob['never'], ob['dc'], ob['m89'], ob.get('cross', 0)))
        st = pl['stats']
        cl_parts = []
        for s, nm in (('pre', '潜伏'), ('dk', '登康式'), ('never', '从未破线'), ('dc', '双穿阳线'),
                      ('m89', '89金叉启动'), ('cross', '穿线阳')):
            if st[s]['closed']:
                cl_parts.append('%s 平仓%d笔 胜率%s%% 均收益%s%%' % (
                    nm, st[s]['closed'], st[s]['win'], st[s]['avg_ret']))
        lines.append('- 前向统计（已平仓）：%s' % ('；'.join(cl_parts) or '暂无平仓记录，数据积累中'))
        lo_parts = []
        for s, nm in (('pre', '潜伏'), ('dk', '登康式'), ('never', '从未破线'), ('dc', '双穿阳线'),
                      ('m89', '89金叉启动'), ('cross', '穿线阳')):
            lo = (st[s].get('loss') or {})
            if lo.get('closed'):
                lo_parts.append('%s 平仓%d笔 胜率%s%% 均%s%%' % (nm, lo['closed'], lo['win'], lo['avg_ret']))
        if lo_parts:
            lines.append('- 亏损股子集（PE≤0，单列验证）：%s' % '；'.join(lo_parts))

    # ⑦ 三线池 + 全量跟踪：报告段落统一由 tl_report.py 生成（独立报告同源码，避免两份口径漂移）
    try:
        import tl_report as _tlr
        _tp = _tlr._j(BASE + '/webapp/tlpool.json')
        _ts = _tlr._j(BASE + '/webapp/tltrack/stats.json')
        _evlib = _tlr._j(BASE + '/webapp/events.json')
        lines.extend(_tlr.sections(_tp, _ts, _evlib, out, inline=True))
    except Exception as _e:
        lines.append('- 三线池/跟踪报告段生成失败：%s' % _e)
    # ⑧ 龙头战法：同源码生成日报段与独立专题报告
    try:
        import dragon_report as _dgr
        lines.extend(_dgr.sections(_dgr._j(BASE + '/webapp/dragon.json'), out, inline=True))
    except Exception as _e:
        lines.append('- 龙头战法报告段生成失败：%s' % _e)
    # ⑨ 背离金叉 lead：全量候选进池 + ≥30日跟踪（回测）
    try:
        import json as _json
        dvt = out.get('divtrack') or {}
        dcr = out.get('divcross') or {}
        if 'error' not in dvt:
            d5 = dvt.get('d5') or {}
            _st = _json.load(open(BASE + '/webapp/divtrack/stats.json')) if os.path.exists(BASE + '/webapp/divtrack/stats.json') else {}
            _bk = (_st.get('buckets') or {}).get('MA89刚勾(0~0.6%)', {})
            _bk5 = _bk.get('d5', {})
            lines.append('## ⑨ 背离金叉 lead（MA89下行+EXPMA上行+EMA12上穿MA89 · 早期位）')
            lines.append('- 当前全量候选 **%d** 只进池（**不按距交叉>3日剔除**，近3日新交叉 %d 只）→ 工作台 p10。' % (
                dvt.get('n', dcr.get('n', 0)), dcr.get('n_fresh3', 0)))
            lines.append('- 全历史跟踪信号 %d 个（成熟 %d / 跟踪中 %d）；5日均值 %s%%、胜率 %s%%、超额 %s%%（等权小盘基准）。' % (
                dvt.get('n_signals', 0), dvt.get('matured', 0), dvt.get('tracking', 0),
                d5.get('avg'), d5.get('win'), d5.get('excess')))
            if _bk5.get('avg') is not None:
                lines.append('- 回测要点：MA89「刚勾(0~0.6%%)」分桶 5日 **%s%%**、胜率 **%s%%**（正向）；仍深跌(<-6%%)判俯冲陷阱已剔除。' % (
                    _bk5.get('avg'), _bk5.get('win')))
    except Exception as _e:
        lines.append('- 背离金叉报告段生成失败：%s' % _e)
    lines.append('')
    lines.append('> 结果为客观数据筛选，不构成投资建议。工作台：http://127.0.0.1:%d' % PORT)
    rep = os.path.join(DAILY_DIR, '日报_%s.md' % ds)
    open(rep, 'w').write('\n'.join(lines))
    out['report'] = rep
    # 独立交付：每日另存一份「三线池与跟踪」专题报告（与日报 ⑦ 段同源码）
    try:
        import tl_report as _tlr2
        _sp = _tlr2.write_standalone()
        if _sp:
            out['tl_report'] = _sp
    except Exception as _e:
        out['tl_report'] = {'error': str(_e)}
    # 独立交付：龙头战法专题报告
    try:
        import dragon_report as _dgr2
        _dpool = _dgr2._j(BASE + '/webapp/dragon.json')
        _dp = _dgr2.write_standalone(_dpool)
        if _dp:
            out['dragon_report'] = _dp
    except Exception as _e:
        out['dragon_report'] = {'error': str(_e)}

print(json.dumps(out, ensure_ascii=False))
