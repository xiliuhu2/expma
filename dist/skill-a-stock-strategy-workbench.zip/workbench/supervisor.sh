#!/bin/bash
# EXPMA 工作台守护：确保 server.py + alertd.py 常驻运行（被 LaunchAgent 与 .app 共用）
# server.py  = 策略工作台 HTTP 服务 (127.0.0.1:8765)
# alertd.py  = 止损/止盈/移动止盈 到价通知（macOS 通知中心，盘中 9:25-15:05 每60秒）
W="$HOME/./webapp"
LOG="$W/launchd.log"
PYTHON="$(command -v python3)"

ensure() { # $1=pgrep特征串 其余=启动命令
  pgrep -f "$1" >/dev/null 2>&1 || {
    shift
    nohup "$@" >>"$LOG" 2>&1 &
  }
}

while true; do
  ensure "Claw/webapp/server\.py" "$PYTHON" "$W/server.py" 8765
  ensure "Claw/webapp/alertd"     "$PYTHON" "$W/alertd.py"
  ensure "Claw/webapp/tlbreak_alert" "$PYTHON" "$W/tlbreak_alert.py"
  sleep 15
done
