#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""三线穿阳·破20日高 盘中提醒守护进程（两层轮询省查询版）。

设计（先筛选踢掉远的，再小池轮询）：
  全量层：每 FULL_SECS 秒（默认15分钟）从工作台拉全量监控清单（/api/tlbreak_watch，
          今日2338只）并整表轮询一遍腾讯行情——既是兜底安全网（捕捉快速拉升越过
          5%走廊直接穿线的票），也用实时价重建「贴近池」。
  贴近层：两次全量之间每 CYCLE 秒（默认60秒）只轮询「贴近池」——实时价距突破价
          trigger ≤ DIST_MAX(5%) 且尚未越过、开盘未高于三线最低值、今日未提醒过的票
          （约800只）。离条件远的（≥5%开外）全部踢出不查询。
  贴近池为空时自动退化为全量扫描（如开盘前行情未就绪）。
触发条件（实时价满足）：
  1) 阳线进行中：现价 > 开盘价
  2) 阳柱实体吞没三线：开盘价 <= min(EMA12, EMA50, MA89)
  3) 突破：现价 >= trigger = max(三线最高值, 近20日最高收盘)（严格大于）
即 macOS 通知 + 记录 webapp/tlbreak_alerts.json（每股每日只提醒一次）。

口径说明：盘中通知是「预触发」——今日收盘的 EMA 要收盘后才知道（用最近收盘值近似）；
收盘确认以三线池/日报口径为准（三线池只认「收盘破20日高」）。
用法：python3 tlbreak_alert.py [--dry]   dry=只打印不弹通知（测试用）
     supervisor.sh 常驻；daily_run.py 每日收盘后随 alertd 一起重启。"""
import datetime, json, os, subprocess, sys, time, urllib.request

from flashwin import flash

WEB = os.path.expanduser('~/WorkBuddy/Claw/webapp')
RECS = os.path.join(WEB, 'tlbreak_alerts.json')
SRV = 'http://127.0.0.1:8765'
DRY = '--dry' in sys.argv
CYCLE = 60          # 轮询周期（秒）
FULL_SECS = 900     # 全量扫描周期（秒）：重建贴近池 + 兜底
DIST_MAX = 0.05     # 距突破价 ≤5% 才进贴近池

_kind = '🔺三线穿阳·破20日高(盘中)'


# 运行态：W=全量监控清单 {完整代码: 条目}；near=贴近池(完整代码集合)；
# full_ts=上次全量扫描时间；fired=今日已提醒代码集合
STATE = {'W': {}, 'near': set(), 'full_ts': 0.0, 'fired': set()}


def quotes(codes):
    """腾讯实时行情：返回 {bare_code: {name, price, open, prev_close, high}}"""
    out = {}
    if not codes:
        return out
    url = 'https://qt.gtimg.cn/q=' + ','.join(codes)
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    text = urllib.request.urlopen(req, timeout=10).read().decode('gbk', 'ignore')
    for line in text.strip().split(';'):
        line = line.strip()
        if not line or '=' not in line:
            continue
        val = line.split('=', 1)[1].strip('"').split('~')
        if len(val) > 34:
            try:
                out[val[2]] = dict(name=val[1],
                                   price=float(val[3]) if val[3] else 0,
                                   prev_close=float(val[4]) if val[4] else 0,
                                   open=float(val[5]) if val[5] else 0,
                                   high=float(val[33]) if val[33] else 0)
            except ValueError:
                pass
    return out


def notify(title, msg, url=''):
    if DRY:
        print('[DRY] %s | %s' % (title, msg))
        return
    # 1) 闪屏窗（置顶红白闪烁 5 秒，点击 → Chrome 打开该票 K 线）
    flash(title, msg, url)
    # 2) macOS 系统通知（横幅 + Glass 提示音，进通知中心可回看）
    msg = msg.replace('"', "'")
    subprocess.run(['osascript', '-e',
                    'display notification "%s" with title "%s" sound name "Glass"' % (msg, title)],
                   capture_output=True)


def fetch_watch():
    """拉全量监控清单，更新 STATE['W']。"""
    req = urllib.request.Request(SRV + '/api/tlbreak_watch', headers={'User-Agent': 'Mozilla/5.0'})
    data = json.load(urllib.request.urlopen(req, timeout=30))
    watch = data.get('watch') or []
    STATE['W'] = {w['code']: w for w in watch}
    return watch


def poll(codes):
    """批量拉行情（每批80只，带 sh/sz 前缀）。"""
    qs = {}
    for i in range(0, len(codes), 80):
        try:
            qs.update(quotes(codes[i:i + 80]))
        except Exception as e:
            print('quotes batch error:', e)
        time.sleep(0.3)          # 批间稍作间隔，避免触发行情源限频
    return qs


def evaluate(qs):
    """对拿到的行情逐票判定触发条件，返回本次提醒记录列表。"""
    today = datetime.date.today().isoformat()
    try:
        recs = json.load(open(RECS))
    except Exception:
        recs = []
    fired = []
    for bare in sorted(qs):
        w = STATE['W'].get(bare)
        if not w:
            continue
        q = qs[bare]
        o, px = q['open'], q['price']
        if o <= 0 or px <= 0 or not (px > o):
            continue                       # 非阳线进行中（含收盘价<=开盘价的阴线）
        if o > w['lo'] + 1e-9:
            continue                       # 开盘已高于最低线：实体无法吞没三线
        if px <= w['trigger']:
            continue                       # 严格大于才算突破（等于昨日收盘不破20日高）
        key = '%s|%s|%s' % (today, w['code'], _kind)
        if any(a.get('key') == key for a in recs):
            continue
        grade = 'MA89上行·A级特征' if w['s89'] > 0 else 'MA89仍下行·B级特征'
        msg = ('现价 %.2f 站上 %.2f · 开盘 %.2f 已吞没三线 · %s · 20日高 %.2f —— '
               '盘中为预触发，收盘站稳才确认；勿追高开，等回踩三线带低吸。'
               % (px, w['trigger'], o, grade, w['hi20']))
        rec = dict(key=key, date=today,
                   time=datetime.datetime.now().strftime('%H:%M:%S'),
                   code=w['code'], name=(q['name'] or w['name']), kind=_kind,
                   msg=msg, price=px, trigger=w['trigger'], s89=w['s89'])
        recs.append(rec)
        fired.append(rec)
        notify('%s · %s' % (_kind, rec['name']), msg,
               SRV + '/?jump=%s/p1' % w['code'])   # 点击闪窗 → Chrome 打开该票 K 线(顶栏可见策略/池子归属)
    if fired:
        json.dump(recs[-300:], open(RECS, 'w'), ensure_ascii=False, indent=1)
        for r in fired:
            STATE['fired'].add(r['code'])
    return fired


def rebuild_near(qs, base_codes):
    """用实时行情重建贴近池：距突破价≤5%、未越过、开盘未高于最低线、今日未提醒。"""
    near = set()
    for code in base_codes:
        w = STATE['W'].get(code)
        if not w or code in STATE['fired']:
            continue
        q = qs.get(code[2:])            # 行情字典以裸代码为键
        if not q or q['price'] <= 0:
            continue
        px = q['price']
        if px > w['trigger']:
            continue                        # 已越过突破价：已提醒或当日结构性不触发
        if w['trigger'] / px - 1 > DIST_MAX:
            continue                        # 离得远 → 踢出，不查询
        if q['open'] > w['lo'] + 1e-9:
            continue                        # 当日开盘已注定无法吞没三线
        near.add(code)
    STATE['near'] = near
    return len(near)


def check():
    """一轮检查。全量扫描（15分钟一次或贴近池为空）时重建贴近池；平时只拉贴近池。"""
    now = time.time()
    full = (now - STATE['full_ts'] >= FULL_SECS) or not STATE['near'] or not STATE['W']
    if full:
        fetch_watch()
        codes = sorted(STATE['W'])
    else:
        codes = sorted(STATE['near'])
    if not codes:
        return []
    qs = poll(codes)
    fired = evaluate(qs)
    if full:
        n = rebuild_near(qs, codes)
        STATE['full_ts'] = now
        print('%s 全量扫描 %d 只 → 贴近池 %d 只（距突破价≤%d%%）'
              % (datetime.datetime.now().strftime('%H:%M:%S'), len(codes), n, DIST_MAX * 100))
    return fired


def main():
    print('tlbreak_alert started: 贴近池每%ds + 全量扫描每%ds '
          '(9:26-11:30, 13:00-15:02 工作日)%s' % (CYCLE, FULL_SECS, ' [DRY]' if DRY else ''))
    while True:
        now = datetime.datetime.now()
        if now.weekday() < 5:
            mins = now.hour * 60 + now.minute
            if (9 * 60 + 26 <= mins <= 11 * 60 + 30) or (13 * 60 <= mins <= 15 * 60 + 2):
                try:
                    fired = check()
                    if fired:
                        print(now.strftime('%H:%M:%S'), 'fired:', ', '.join(
                            '%s(%s)' % (r['name'], r['code']) for r in fired))
                except Exception as e:
                    print('check error:', e)
        time.sleep(CYCLE)


if __name__ == '__main__':
    main()
