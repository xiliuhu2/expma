#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""抓取四大指数日K并缓存为统一格式 [date, open, close, high, low, vol]"""
import json, os, urllib.request

OUT = os.path.expanduser('~/WorkBuddy/Claw/backtest/indices')
os.makedirs(OUT, exist_ok=True)

def tx_kline(code, n=800):
    url = 'https://web.ifzq.gtimg.cn/appstock/app/kline/kline?param=%s,day,,,%d,' % (code, n)
    d = json.loads(urllib.request.urlopen(urllib.request.Request(
        url, headers={'User-Agent': 'Mozilla/5.0'}), timeout=15).read())
    return d['data'][code].get('day') or []

def em_kline(secid):
    url = ('https://push2his.eastmoney.com/api/qt/stock/kline/get?secid=%s'
           '&fields1=f1,f2,f3,f4,f5,f6&fields2=f51,f52,f53,f54,f55,f56,f57'
           '&klt=101&fqt=0&beg=20230101&end=20500101' % secid)
    d = json.loads(urllib.request.urlopen(urllib.request.Request(
        url, headers={'User-Agent': 'Mozilla/5.0'}), timeout=15).read())
    rows = []
    for x in d['data']['klines']:
        p = x.split(',')   # date, open, close, high, low, vol, amount
        rows.append([p[0], float(p[1]), float(p[2]), float(p[3]), float(p[4]), float(p[5] or 0)])
    return rows

IDX = {
    'sh000300': ('沪深300', lambda: tx_kline('sh000300')),
    'sh000001': ('上证指数', lambda: tx_kline('sh000001')),
    'sh000688': ('科创50', lambda: tx_kline('sh000688')),
    'sz399006': ('创业板指', lambda: tx_kline('sz399006')),
    'bj899050': ('北证50', lambda: em_kline('0.899050')),
}

for code, (name, fn) in IDX.items():
    try:
        k = fn()
        if len(k) > 60:
            rows = [[r[0], float(r[1]), float(r[2]), float(r[3]), float(r[4]), float(r[5] or 0)] for r in k]
            json.dump(rows, open(os.path.join(OUT, code + '.json'), 'w'))
            print('%s %s: %d bars %s -> %s' % (code, name, len(rows), rows[0][0], rows[-1][0]))
        else:
            print('%s %s: 仅%d根，跳过' % (code, name, len(k)))
    except Exception as e:
        print('%s %s: FAIL %s' % (code, name, e))
