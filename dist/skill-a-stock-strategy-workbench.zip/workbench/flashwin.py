#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""共享闪屏提醒窗（供 alertd.py / tlbreak_alert.py 两个守护进程使用）。

独立子进程运行 tkinter：无边框置顶小窗，按信号类型的主色与白色交替闪烁 5 秒自动关闭
（止损=绿 / 止盈与买入信号=红），点击窗体 → 关窗 + 用 Chrome 打开传入的 URL
（无 Chrome 回退默认浏览器）。启动即崩（macOS WindowServer 偶发竞争）自动重试一次。
每次弹出/退出原因记录 webapp/tlbreak_flash.log，便于排查「窗不见了」。"""
import os, subprocess, sys, time

FLASH_SRC = r'''
import datetime, os, subprocess, sys, tkinter as tk
title, msg, url = sys.argv[1], sys.argv[2], (sys.argv[3] if len(sys.argv) > 3 else '')
color = sys.argv[4] if len(sys.argv) > 4 and sys.argv[4] else '#c02626'   # 主色：止损绿/止盈红等
LOGF = os.path.expanduser('~/WorkBuddy/Claw/webapp/tlbreak_flash.log')
def log(why):
    try:
        open(LOGF, 'a').write('%s %s %s\n' % (
            datetime.datetime.now().strftime('%H:%M:%S'), why, title[:40]))
    except Exception:
        pass
r = tk.Tk()
r.attributes('-topmost', True)
r.overrideredirect(True)
r.configure(cursor='hand2')
lbl1 = tk.Label(r, text=title, font=('PingFang SC', 13, 'bold'), wraplength=300)
lbl2 = tk.Label(r, text=msg, font=('PingFang SC', 10), wraplength=300, justify='left')
lbl3 = tk.Label(r, text='👉 点击在 Chrome 查看', font=('PingFang SC', 9))
lbl1.pack(pady=(8, 2), padx=14)
lbl2.pack(padx=14)
lbl3.pack(padx=14, pady=(4, 8))
st = {'hot': True, 't': 0.0, 'why': None}
def paint():
    hot = st['hot']
    bg = color if hot else '#ffffff'
    for x in (r, lbl1, lbl2, lbl3):
        x.configure(bg=bg)
    lbl1.configure(fg='#ffffff' if hot else '#1a1a1a')
    lbl2.configure(fg='#ffe08a' if hot else '#333333')
    lbl3.configure(fg='#ffffff' if hot else '#1d4ed8')
def place():
    r.update_idletasks()
    w = r.winfo_reqwidth()
    h = r.winfo_reqheight()
    r.geometry('+%d+%d' % (r.winfo_screenwidth() - w - 16, 48))
    r.lift()
def openurl(e):
    st['why'] = 'click→关闭并打开Chrome' if url else 'click→关闭(无链接)'
    r.destroy()
    if url:
        try:
            subprocess.Popen(['open', '-a', 'Google Chrome', url])
        except Exception:
            subprocess.Popen(['open', url])       # 无 Chrome 走默认浏览器
def tick():
    st['t'] += 0.4
    if st['t'] > 5:              # 显示 5 秒自动关，点击可提前关+跳转
        st['why'] = 'timeout→5秒自动关'
        r.destroy()
        return
    st['hot'] = not st['hot']
    paint()
    r.after(400, tick)
r.bind('<Button-1>', openurl)
r.after(50, place)
r.after(900, place)          # 显示后重申一次，防 macOS 把无边框窗挪回左上角
log('start')
paint()
tick()
r.mainloop()
log(st['why'] or 'exit-unknown→mainloop结束但非点击/超时')
'''


RED = '#c02626'      # 止盈/买入信号（红=看多动作）
GREEN = '#0d8a45'    # 止损（绿=离场保护）


def spawn_flash(title, msg, url='', color=RED):
    return subprocess.Popen([sys.executable, '-c', FLASH_SRC, title, msg, url or '', color],
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                            start_new_session=True)   # 脱离父进程组，防命令结束时被连带杀掉


def flash(title, msg, url='', color=RED):
    """弹闪屏窗（带启动即崩重试）。color=闪烁主色，默认红。"""
    try:
        p = spawn_flash(title, msg, url, color)
        time.sleep(1.5)
        if p.poll() is not None:
            p = spawn_flash(title, msg, url, color)   # 偶发启动即崩 → 立即重试一次
    except Exception as e:
        print('flash error:', e)
