---
name: a-stock-strategy-workbench
version: 1.0.1
display_name: "A股策略工作台"
display_name_en: "A-Stock Strategy Workbench"
description: "A股策略工作台：本地量化选股与盯盘系统。当日线收盘跑批（六策略筛选/三线池/龙头战法/情绪周期/前向验证）、盘中「三线穿阳破20日高」实时提醒、持仓止盈止损到价提醒、查询某只股票命中哪些策略池、生成每日策略日报时使用。触发词：收盘跑批、策略工作台、三线池、龙头战法、六策略、涨停池、情绪周期、穿三线、龙溪形态、精选池。"
description_zh: "A股量化选股与盯盘工作台。每日收盘一键跑批：全市场约5000只个股数据更新、六策略筛选（潜伏爆发/登康式/从未破线/双穿阳/89金叉/三线穿阳）、三线池Top5评级定价、龙头战法分级与陷阱名单、情绪周期与涨停池复盘、精选池前向验证，自动生成三份策略日报；盘中实时捕捉「三线穿阳+破20日高」（A级买点）弹窗提醒，持仓止盈止损到价提醒（止损绿/止盈红闪窗）。内置全历史回测口径与合规提示。本地Web界面，纯Python标准库零依赖。"
description_en: "A-share quant stock-picking workbench. One-command daily batch after market close updates market-wide data (~5000 stocks), screens six strategies, grades the Three-Line Pool Top5, classifies dragon-head candidates with trap detection, tracks sentiment cycle and limit-up ladder, runs forward validation, and generates three daily reports. Intraday real-time alerts for three-line cross plus 20-day-high breakout (Grade-A entry) and stop-loss/take-profit triggers with color-coded flashing windows. Includes full backtest methodology and compliance notices. Local web UI, pure Python stdlib, zero dependencies."
agent_created: true
---

# A股策略工作台（A-Stock Strategy Workbench）

本地量化选股工作台：全市场约5000只个股日K + 六策略筛选 + 三线池/龙头战法深度体系 + 前向验证跟踪 + 本地 Web 界面（127.0.0.1:8765）+ 盘中实时提醒。纯 Python 标准库实现，无第三方依赖，数据来自公开行情接口（腾讯/东财）。

## 首次安装（仅在目标机器缺少 `~/WorkBuddy/Claw` 时执行）

1. 运行 `python3 <skill目录>/scripts/setup_workbench.py`——把代码骨架装到 `~/WorkBuddy/Claw`（已有文件跳过，数据文件永不覆盖；`--force` 可强制覆盖代码）。
2. 首日初始化：`python3 ~/WorkBuddy/Claw/webapp/daily_run.py`（抓指数/行业/概念/全市场K线并跑批，约5-10分钟；此后每日收盘重跑约2-5分钟）。退出码为 0 即成功。
3. 打开 http://127.0.0.1:8765 验证工作台。

## 每日工作流（用户说"收盘跑批"时）

后台运行 `python3 ~/WorkBuddy/Claw/webapp/daily_run.py`（约2-5分钟，概念板块每5天重抓会额外约2分钟），完成后校验退出码为 0，读 `~/WorkBuddy/Claw/daily/` 下三份日报（日报_当日期.md / 三线池与跟踪_当日期.md / 龙头战法_当日期.md），按日报数值汇报：①regime与情绪周期；②六策略命中数；③涨停家数与最高连板；④精选池本周绩效；⑤概念主线Top3；⑥三线池Top5（评级/评分/低吸区/确认价/硬止损，A级不足5只要提示其余为B级追高陷阱区）；⑦穿三线跟踪进度与前向均值；⑧龙头战法结论（A级/B级/D级数量、空间龙头、龙头池Top8、陷阱名单、全历史前向验证关键结论）。stdout 含 dragon_report 时用 present_files 展示龙头战法日报与 `webapp/dragon/signals.csv`。

## 查询个股归属（用户问"XX在哪个池子"时）

调 `curl "http://127.0.0.1:8765/api/locate?code=<sh|sz+6位代码或中文名>"`，返回该票当日命中的六策略、观察池、三线池、龙头战法、背离金叉、沪深300池、涨停信息。工作台搜索框输入名称/代码也会自动显示归属标签。判断"是否符合龙溪形态"用背离金叉口径（见 references/strategy-guide.md §5）。

## 盘中提醒（安装后自动随跑批重启）

- **三线穿阳·破20日高**（A级硬门槛）：tlbreak_alert.py 守护盘中实时捕捉，触发即 macOS 闪窗（红）+ 横幅通知，记录 `webapp/tlbreak_alerts.json`。工作台三线池页签有"⏳即将穿三线池"（距突破价≤5%，15分钟刷新）。
- **持仓止盈止损**：alertd.py 监控 trades.json（交易计划页录入），止损闪窗绿色、止盈红色，记录 `webapp/alerts.json`。
- 通知为 macOS 专用（osascript+tkinter），其他系统仅落盘记录。监控口径与回测结论见 references/strategy-guide.md。

## 回答口径（必须遵守）

- 所有评级/评分/回测数值以当日报告与 JSON 输出为准，本文档只给规则与量级。
- 涉及买卖建议时必须附合规提醒：客观量化筛选，不构成投资建议，历史正期望不代表未来。
- Regime 下行 ▼ 时主动提示"按回测规则应空仓观察"；龙头战法无 A 级时明确提示轻仓/空仓，不把 B 级当龙头重仓。

## 文件地图

- 代码：`~/WorkBuddy/Claw/webapp/`（server.py 工作台服务、pool.py 六策略、tlpool.py 三线池、dragon.py 龙头战法、daily_run.py 跑批、alertd.py/tlbreak_alert.py 盘中守护、flashwin.py 闪窗）；`~/WorkBuddy/Claw/backtest/`（fetch_*.py 数据抓取、回测脚本）。
- 数据：`backtest/klines/`（全市场日K，可由 fetch_klines.py 重新抓取）；当日结果 `webapp/*.json`；前向跟踪库 `webapp/tltrack|dragon|divtrack/`（不可再生，勿删）；用户持仓 `webapp/trades.json`。
- 日报：`~/WorkBuddy/Claw/daily/`。
