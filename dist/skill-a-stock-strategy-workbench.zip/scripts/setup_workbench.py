#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""安装 A 股策略工作台到 .（与代码内置路径约定一致）。

行为：
1. 检查目标目录；已存在的代码文件默认跳过（--force 覆盖），数据文件（*.json/csv）永不触碰。
2. 在 assets 的 workbench 代码目录中按文件名映射目的地：
   - 回测/抓取脚本（fetch_*、dq_check、baseline_regime）→ <target>/backtest/
   - 其余 .py/.html/.sh → <target>/webapp/
   （兼容 assets/workbench/{webapp,backtest}/ 嵌套布局与 workbench/ 平铺布局两种来源）
3. 打印后续步骤（首日数据抓取与跑批命令），不自动执行抓取（全市场K线首次约几分钟）。

用法：python3 setup_workbench.py [--force] [--target .]
"""
import argparse, os, shutil, sys

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CODE_EXT = ('.py', '.html', '.sh')
BACKTEST_FILES = {'fetch_klines.py', 'fetch_industry.py', 'fetch_concepts.py',
                  'fetch_indices.py', 'fetch_hs300.py', 'fetch_bond.py',
                  'dq_check.py', 'baseline_regime.py'}


def find_src():
    """定位 workbench 代码目录：优先 assets/workbench（含或不含子目录），否则报错。"""
    base = os.path.join(SKILL_DIR, 'assets', 'workbench')
    if os.path.isdir(base):
        return base
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--force', action='store_true', help='覆盖已存在的同名代码文件')
    ap.add_argument('--target', default=os.path.expanduser('.'))
    a = ap.parse_args()
    dst = os.path.abspath(os.path.expanduser(a.target))
    src = find_src()
    if not src:
        print('ERROR: 找不到 assets/workbench，请确认 skill 完整安装'); sys.exit(1)

    # 收集全部代码文件 → 目的子目录
    plan = []                              # (src_path, dest_path)
    for root, _dirs, files in os.walk(src):
        for f in files:
            if not f.endswith(CODE_EXT):
                continue                   # 数据/缓存一律不安装
            sub = 'backtest' if f in BACKTEST_FILES else 'webapp'
            plan.append((os.path.join(root, f), os.path.join(dst, sub, f)))
    if not plan:
        print('ERROR: assets/workbench 下没有可安装的代码文件'); sys.exit(1)

    n_new = n_skip = 0
    for s, t in plan:
        os.makedirs(os.path.dirname(t), exist_ok=True)
        if os.path.exists(t) and not a.force:
            n_skip += 1
            continue
        shutil.copy2(s, t)
        n_new += 1
    print('安装完成：%s（新写 %d 个文件，跳过已存在 %d 个）' % (dst, n_new, n_skip))
    print('后续步骤：')
    print('  1. 首日初始化（抓指数/行业/概念/全市场K线并跑批，约5-10分钟）：')
    print('     python3 %s/webapp/daily_run.py' % dst)
    print('  2. 打开工作台：http://127.0.0.1:8765')
    print('  3. 此后每个交易日收盘后重跑 daily_run.py 即可（盘中提醒守护随跑批自动重启）。')


if __name__ == '__main__':
    main()
